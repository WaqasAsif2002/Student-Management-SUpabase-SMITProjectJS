

let currentUserId = JSON.parse(localStorage.getItem("CurrentUser"))
console.log(currentUserId.id)

let logoutBtn = document.getElementById("logout_btn")
let showMyPosts = document.getElementById("showMyPosts")




async function logoutUser() {
    try {
        const { error } = await supabase.auth.signOut()
        checkCurrentPage()
    } catch (error) {
        console.log(error)
    }
}
logoutBtn.addEventListener("click", logoutUser)


async function deletePost(postId) {
    try {
        Swal.fire({
            title: "Are you sure?",
            showCancelButton: true,
            confirmButtonText: "Delete",
        }).then(async (result) => {
            if (result.isConfirmed) {
                const { data, error } = await supabase
                    .from("Posts")
                    .delete()
                    .eq("id", postId)
                    .select();

                if (error) throw error;

                try {
                    const { data : SavedPostDeleteData, error : SavedPostDeleteError } = await supabase
                        .from('SavedPosts')
                        .delete()
                        .eq('PostId', postId)
                        .select()
                    if(SavedPostDeleteError) throw SavedPostDeleteError
                    if(SavedPostDeleteData){
                        console.log(SavedPostDeleteData)
                    }

                } catch (error) {
                    console.log(error)
                }
                if (data) {
                    
                    location.reload()


                    // setTimeout(() => {
                    //     location.reload()
                    // }, 2000);

                }



            }
        });
    } catch (error) {
        console.log(error);
    }
}

async function showAllMyPosts() {
    try {
        const { data, error } = await supabase
            .from('Posts')
            .select()
        if (error) throw error
        if (data) {
            // console.log(data)
            data.map(async (item) => {
                if (item.UserId == currentUserId.id) {
                    try {
                        const { data: UserNameData, error: UserNameError } = await supabase
                            .from('Users')
                            .select('UserName')
                            .eq('UserId', `${currentUserId.id}`)
                        if (UserNameError) throw error
                        if (UserNameData) {
                            // console.log(UserNameData[0].UserName)
                            // console.log(item.UserId)
                            // console.log(item)
                            showMyPosts.innerHTML += `
                                <div class="col col-12 col-sm-6 col-md-6 col-lg-4 col-xl-4 col-xxl-4 p-0 text-center">
                                            <div class="card my-3" style="width: 260px; height: 400px; margin:0px auto;">
                          <div class="card-header text-start d-flex justify-content-between" >
                          <div>
                           ${UserNameData[0].UserName}
                           <br>${item.created_at.slice(0, 10)}
                           </div>
                           <div class="d-flex align-items-center">
                           <i onclick="deletePost(${item.id})" class="fa-solid fa-trash "></i>
                           </div>
                          </div>
                          <div class="card-body">
            
                            
                            <img class="card-img-top my-3" height="150px" width="60px" src="${item.PostImageURL}" alt="Image"> 
                            <div style="height: 50px; margin-top: 10px;"><p class="card-text text-start"><b>${item.PostContent}</b></p></div>
                            <button onclick="deletePost(${item.id})" class="btn btn-dark my-3" style="width:80%; margin: 0px auto;">Delete</button>
                            
                          </div>
                        </div>
                        </div>
                                `
                        }
                    } catch (error) {
                        console.log(error)
                    }

                }
                else {

                }
            })
        }
    } catch (error) {
        console.log(error)
    }
}


let SavedPosts = document.getElementById("Saved")
function MoveToSavedPosts() {
    window.location.href = "saved.html"
}
if (SavedPosts) {
    SavedPosts.addEventListener("click", MoveToSavedPosts)
}



let home = document.getElementById("Home")
function GoToHomePage() {
    window.location.href = "dashboard.html"
}
if (home) {
    home.addEventListener("click", GoToHomePage)
}

window.onload = showAllMyPosts()


window.deletePost = deletePost;