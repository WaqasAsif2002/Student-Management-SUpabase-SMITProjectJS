let loginEmail = document.getElementById("LogInEmail")
let loginPass = document.getElementById("LogInPass")
let loginBtn = document.getElementById("LogInBtn")
if (loginBtn) {
    loginBtn.addEventListener("click", logIn)
}


async function checkCurrentPage() {
    let currentPath = window.location.pathname
    console.log(currentPath)

    try {
        const { data, error } = await supabase.auth.getSession();
        const { session } = data
        console.log(session)
        let arrayOfPages = ["/", "/index.html", "/login.html"]
        let userCurrentPage = arrayOfPages.includes(currentPath)
        console.log(userCurrentPage)
        if (session) {
            if (userCurrentPage) {
                window.location.href = "/dashboard.html"
            }
        } else {
            if (!userCurrentPage) {
                window.location.href = "/login.html"
            }
        }
    } catch (error) {
        console.log(error)
    }
}
window.checkCurrentPage = checkCurrentPage
window.onload = checkCurrentPage()
async function logIn() {
    if (loginEmail.value.trim() === "" || loginPass.value.trim() === "") {
        Swal.fire({
            title: "Invalid Input",
            text: "Please fill in all fields",
            icon: "question",
        });
    }
    else {
        try {

            let { data, error } = await supabase.auth.signInWithPassword({
                email: loginEmail.value,
                password: loginPass.value
            })

            if (error) {
                Swal.fire(error.message)
            } 
            if (data) {
                console.log(data)
                localStorage.setItem("CurrentUser" , JSON.stringify(data.user))
                window.location.href = "./dashboard.html"
                // let currentUserId = JSON.parse(localStorage.getItem("CurrentUser"))
                // console.log(currentUserId.id)
            }

        
        } catch (error) {
            console.log(error)
        }
        finally {
            console.log(loginEmail.value)
            console.log(loginPass.value)
            loginEmail.value = ""
            loginPass.value = ""

        }


    }


}
