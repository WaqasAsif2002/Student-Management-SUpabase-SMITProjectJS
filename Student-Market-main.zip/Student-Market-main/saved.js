

let currentUserId = JSON.parse(localStorage.getItem("CurrentUser"))
let MyPosts = document.getElementById("MyPosts")
function MoveToMyPosts() {
    window.location.href = "MyPosts.html"
}
if (MyPosts) {
    MyPosts.addEventListener("click", MoveToMyPosts)
}



let home = document.getElementById("Home")
function GoToHomePage() {
    window.location.href = "dashboard.html"
}
if (home) {
    home.addEventListener("click", GoToHomePage)
}
let savedIcon = document.getElementById("savedIcon")
async function Unsave(postId) {
    console.log(postId)
    try {
        const { data, error } = await supabase
            .from('SavedPosts')
            .delete()
            .eq('id', postId)
            .select()
        if (error) throw error
        if (data) {
            console.log(data)
            Swal.fire({
                title: "Post Unsaved",
                icon: "success",
                draggable: true
            });
            setTimeout(() => {
                window.location.reload()
            }, 800)

        }
    } catch (error) {
        console.log(error)
    }

}
console.log(currentUserId.id)
async function BuyFromSaved(postID) {
    console.log(postID)
    try {
        const { data, error } = await supabase
            .from('Posts')
            .select('UserId')
            .eq('id', `${postID}`)
            if(error) throw error
            if(data){
                console.log(data)
                if (data[0].UserId == currentUserId.id) {
                    Swal.fire({
                        icon: "error",
                        title: "Can not buy own items",
                    });
                } else {
                    try {
                        const { data, error } = await supabase
                            .from('Posts')
                            .select('Status , UserId')
                            .eq('id', `${postID}`)    // Correct
                        if (error) throw error
                        if (data) {
                            console.log(data)
                            if (data[0].Status == "Sold") {
                                Swal.fire("Item is Sold");
                            } else{
                                Swal.fire({
                                    title: "Confirm Purchase?",
                                    showCancelButton: true,
                                    confirmButtonText: "Confirm",
                                }).then(async (result) => {
                                    if(result.isConfirmed){
                                        Swal.fire({
                                            title: "Item Purchased",
                                            icon: "success",
                                            draggable: true
                                        });
                                        try {
                                            const { data, error } = await supabase
                                                .from('Posts')
                                                .update({ Status: 'Sold'})
                                                .eq('id', postID)
                                                .select()
                                            if (error) throw error
                                            if (data) {
                                                console.log(data)
                                                setTimeout(() =>{
                                                    location.reload()
                                                },1000)
                                            }
                                        } catch (error) {
                                            console.log(error)
                                        }
                                    }
                                })
                            }
                        }
                    } catch (error) {
                        console.log(error)
                    }
                }
            }
    } catch (error) {
        console.log(error)
    }

   
}



let savedpostsContainer = document.getElementById("showSavedPosts")
async function showsavedPosts() {
    try {
        const { data, error } = await supabase
            .from('SavedPosts')
            .select()
        if (error) throw error
        if (data) {
            // console.log(data)
            if (data) {
                data.map((item) => {
                    // console.log(item)
                    // console.log(item.UserId)
                    // console.log(currentUserId.id)
                    if (item.UserId === currentUserId.id) {
                        savedpostsContainer.innerHTML += `
                            <div class="col col-12 col-sm-6 col-md-6 col-lg-4 col-xl-4 col-xxl-4 p-0 text-center">
                                <div class="card my-3" style="width: 260px; height: 400px; margin:0px auto;">
              <div class="card-header text-start d-flex justify-content-between" >
              <div>
               ${item.PostUserName}
               <br>${item.PostCreatedAt.slice(0, 10)}
               </div>
               <div  class="d-flex align-items-center"><i onclick="Unsave('${item.id}')" id="savedIcon"  class="fa-solid fa-bookmark"   ></i></div>
              </div>
              <div class="card-body">

                
                <img class="card-img-top my-3" height="150px" width="60px" src="${item.ImageURL}" alt="Image"> 
                <div style="height: 50px; margin-top: 10px;"><p class="card-text text-start"><b>${item.title}</b></p></div>
                <div class="d-flex justify-content-between"> 
                <div class="d-flex align-items-center text-center" style="width:50%"><b style="margin: 0px auto; font-size : 30px;">${item.Price}$</b></div>
                <button onclick="BuyFromSaved('${item.PostId}' )" class="btn btn-dark my-3" style="width:40%; margin: 0px auto;">Buy</button>

                
              </div>
            </div>
            </div>
            </div>
                        `
                    }
                })
            }
        }
    } catch (error) {
        console.log(error)
    }
}


window.Unsave = Unsave;
window.BuyFromSaved = BuyFromSaved;
window.onload = showsavedPosts();
